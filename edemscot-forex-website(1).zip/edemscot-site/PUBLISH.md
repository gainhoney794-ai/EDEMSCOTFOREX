# Publishing EDEMSCOT FOREX to GitHub Pages

## Option A — Upload in the browser (no tools needed)

1. Go to https://github.com/new
2. Repository name: `edemscot-forex`  →  set to **Public**  →  Create repository
3. Click **"uploading an existing file"**
4. Drag in **everything inside this folder** (`index.html`, `assets/`, `.nojekyll`, `README.md`)
   — do not drag the folder itself, drag its contents
5. Commit changes
6. Go to **Settings → Pages**
   - Source: **Deploy from a branch**
   - Branch: **main** / **(root)**  →  Save
7. Wait 1–2 minutes. Your site is live at:

   https://YOUR-USERNAME.github.io/edemscot-forex/

## Option B — From the terminal

```bash
cd edemscot-site

git init
git add .
git commit -m "EDEMSCOT FOREX landing page"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/edemscot-forex.git
git push -u origin main
```

Then enable Pages as in step 6 above.

## Custom domain (optional)

1. Buy a domain (e.g. edemscotforex.com)
2. In the repo, create a file named `CNAME` containing only:
   ```
   edemscotforex.com
   ```
3. In your domain's DNS, add:
   - `A` record  → `185.199.108.153`, `.109.153`, `.110.153`, `.111.153`
   - or `CNAME` → `YOUR-USERNAME.github.io`
4. GitHub → Settings → Pages → add your custom domain → wait for the check to pass

## Remember before publishing

In `index.html`, near the bottom:

```js
var WA_NUMBER = "2348000000000";                        // WhatsApp, no +
var FB_URL    = "https://facebook.com/edemscotforex";
var YT_URL    = "https://youtube.com/@edemscotforex";
```
